package main

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"net/http"
	"strconv"
	"sync"
)

type User struct {
	ID         string      `json:"id"`
	SecretCode string      `json:"secret_code"`
	Name       string      `json:"name"`
	Email      string      `json:"email"`
	Complaints []Complaint `json:"complaints"`
	Mutex      *sync.Mutex `json:"-"`
}

type Complaint struct {
	ID       string `json:"id"`
	Title    string `json:"title"`
	Summary  string `json:"summary"`
	Rating   int    `json:"rating"`
	Resolved bool   `json:"resolved"`
}

var (
	users      = make(map[string]User)
	usersMutex sync.Mutex
	randSource = rand.NewSource(1)
	randGen    = rand.New(randSource)
)

func main() {
	http.HandleFunc("/login", loginHandler)
	http.HandleFunc("/register", registerHandler)
	http.HandleFunc("/submitComplaint", submitComplaintHandler)
	http.HandleFunc("/getAllComplaintsForUser", getAllComplaintsForUserHandler)
	http.HandleFunc("/getAllComplaintsForAdmin", getAllComplaintsForAdminHandler)
	http.HandleFunc("/viewComplaint", viewComplaintHandler)
	http.HandleFunc("/resolveComplaint", resolveComplaintHandler)

	fmt.Println("Server is listening on port 8080...")
	http.ListenAndServe(":8080", nil)
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	secretCode := r.FormValue("secret_code")
	usersMutex.Lock()
	user, ok := users[secretCode]
	usersMutex.Unlock()
	if !ok {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}
	json.NewEncoder(w).Encode(user)
}

func registerHandler(w http.ResponseWriter, r *http.Request) {
	name := r.FormValue("name")
	email := r.FormValue("email")
	newUserID := strconv.Itoa(randGen.Intn(100000))
	newSecretCode := strconv.Itoa(randGen.Intn(100000))

	newUser := User{
		ID:         newUserID,
		SecretCode: newSecretCode,
		Name:       name,
		Email:      email,
		Complaints: []Complaint{},
		Mutex:      &sync.Mutex{},
	}

	usersMutex.Lock()
	users[newSecretCode] = newUser
	usersMutex.Unlock()

	json.NewEncoder(w).Encode(newUser)
}

func submitComplaintHandler(w http.ResponseWriter, r *http.Request) {
	secretCode := r.FormValue("secret_code")
	title := r.FormValue("title")
	summary := r.FormValue("summary")
	rating, err := strconv.Atoi(r.FormValue("rating"))
	if err != nil {
		http.Error(w, "Invalid rating", http.StatusBadRequest)
		return
	}

	usersMutex.Lock()
	user, ok := users[secretCode]
	usersMutex.Unlock()
	if !ok {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	user.Mutex.Lock()
	defer user.Mutex.Unlock()

	newComplaint := Complaint{
		ID:       strconv.Itoa(randGen.Intn(100000)),
		Title:    title,
		Summary:  summary,
		Rating:   rating,
		Resolved: false,
	}

	user.Complaints = append(user.Complaints, newComplaint)
	usersMutex.Lock()
	users[secretCode] = user
	usersMutex.Unlock()

	json.NewEncoder(w).Encode(newComplaint)
}

func getAllComplaintsForUserHandler(w http.ResponseWriter, r *http.Request) {
	secretCode := r.FormValue("secret_code")

	usersMutex.Lock()
	user, ok := users[secretCode]
	usersMutex.Unlock()
	if !ok {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	user.Mutex.Lock()
	defer user.Mutex.Unlock()

	json.NewEncoder(w).Encode(user.Complaints)
}

func getAllComplaintsForAdminHandler(w http.ResponseWriter, r *http.Request) {
	allComplaints := []struct {
		UserID   string `json:"user_id"`
		Title    string `json:"title"`
		Resolved bool   `json:"resolved"`
	}{}

	usersMutex.Lock()
	for _, user := range users {
		for _, complaint := range user.Complaints {
			allComplaints = append(allComplaints, struct {
				UserID   string `json:"user_id"`
				Title    string `json:"title"`
				Resolved bool   `json:"resolved"`
			}{
				UserID:   user.ID,
				Title:    complaint.Title,
				Resolved: complaint.Resolved,
			})
		}
	}
	usersMutex.Unlock()

	json.NewEncoder(w).Encode(allComplaints)
}

func viewComplaintHandler(w http.ResponseWriter, r *http.Request) {
	secretCode := r.FormValue("secret_code")
	complaintID := r.FormValue("complaint_id")

	usersMutex.Lock()
	user, ok := users[secretCode]
	usersMutex.Unlock()
	if !ok {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	user.Mutex.Lock()
	defer user.Mutex.Unlock()

	for _, complaint := range user.Complaints {
		if complaint.ID == complaintID {
			json.NewEncoder(w).Encode(complaint)
			return
		}
	}

	http.Error(w, "Complaint not found", http.StatusNotFound)
}

func resolveComplaintHandler(w http.ResponseWriter, r *http.Request) {
	secretCode := r.FormValue("secret_code")
	complaintID := r.FormValue("complaint_id")

	usersMutex.Lock()
	user, ok := users[secretCode]
	usersMutex.Unlock()
	if !ok {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	user.Mutex.Lock()
	defer user.Mutex.Unlock()

	for i, complaint := range user.Complaints {
		if complaint.ID == complaintID {
			user.Complaints[i].Resolved = true
			usersMutex.Lock()
			users[secretCode] = user
			usersMutex.Unlock()
			json.NewEncoder(w).Encode(user.Complaints[i])
			return
		}
	}

	http.Error(w, "Complaint not found", http.StatusNotFound)
}
